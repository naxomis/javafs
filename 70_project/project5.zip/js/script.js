// 문서가 준비되면 함수 실행
$(function () {

    // 풀페이지 레이아웃
    $('#fullpage').fullpage({
        // 오른쪽 인디케이터(페이저)
        navigation: true
    });
});