$(function(){

	$( 'body' ).jpreLoader( {
		
		splashID: 'jSplash',	/*연결할 ID*/
		loaderVPos: '48%',		/*로딩바의 세로 위치*/
		autoClose: true,		/*로딩후 자동 페이지 이동*/
		closeBtnText: '잠시 후 시작됩니다'	/*메시지*/
		
	} );

});