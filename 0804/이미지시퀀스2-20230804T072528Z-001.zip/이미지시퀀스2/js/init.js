$(function(){
  var imgs ='';
   //변수초기화
  //이미지  200개를 section 넣기
 for(var i = 0 ; i < 200 ; i++ ){
  
   imgs = imgs + "<img src='images/pic"+i+".jpg'>"
   //console.log(imgs);
   //i=0; <img src='images/pic0.jpg'>
   //i=1;<img src='images/pic0.jpg'> <img src='images/pic1.jpg'>
   //i=2; <img src='images/pic0.jpg'> <img src='images/pic1.jpg'> 
  // <img src='images/pic2.jpg'> 
 }
$('section').html(imgs);


  //마우스 움직일때마다 
$('body').mousemove(function(e){
 //변수 $width에 현재 브라우저 너비값 저장
  var $width = $(window).width(); 
  // console.log($width); - 1920
  
  /*변수 $posX 에 화면 위 마우스 커서의 위치 저장 */
  var $posX = e.pageX;

  var $percent =  Math.floor(($posX / $width)*200);
  // 예를 x 축 100만큼 이동
  //전체 너비 1920   (100/1920) * 200 = 10.41666 - 10
 
  $('h3').text($percent);
   //이미지 번호 h3출력

  //200개 이미지 교체 되면서 차레 대로 나타나야됨
  //모든이미지 숨기고  마우스 계산값에 따라 보여줌
  $('section > img').hide();
  $('section > img').eq($percent).show();

});



  
 

  //프리로더 맨마지막 작업 

$("body").preload(function(){
  var timer = setTimeout(function(){
    $(".preloading").fadeOut(200);
    $("body").show();
    clearTimeout(timer);
  },1000);
});




});